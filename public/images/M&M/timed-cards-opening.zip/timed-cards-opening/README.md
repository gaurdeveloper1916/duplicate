# Timed Cards Opening

A Pen created on CodePen.io. Original URL: [https://codepen.io/dilums/pen/NWodZMd](https://codepen.io/dilums/pen/NWodZMd).

Landing page cards animation with GSAP

Need some more work to get it responsive. So please use [live view](https://codepen.io/dilums/live/NWodZMd) for better results.

Inspiration
[Timed Cards Opening](https://dribbble.com/shots/11012652--Timed-Cards-Opening) by [Giulio Cuscito](https://dribbble.com/Giulio_Cuscito)